package com.example.myapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.simongame.R;
import java.util.Random;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import android.os.Handler;
import android.widget.TextView;

public class game extends AppCompatActivity {
int g = 0;
Button green = (Button) findViewById(R.id.greenbtn);
Button yellow = (Button) findViewById(R.id.yellowbtn);
Button red = (Button) findViewById(R.id.redbtn);
Button blue = (Button) findViewById(R.id.bluebtn);
TextView score = (TextView) findViewById(R.id.currentScore);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        ArrayList<Integer> order = new ArrayList<>();
        int n = 0;
        Random rand = new Random();
        boolean correct = true;

        while (1!=0) {

            order.add(rand.nextInt(4)+1);
            int y = 0;

            while (y != n + 1){
                if (order.get(y) == 1){
                    final ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();
                    executorService.scheduleAtFixedRate(new Runnable() {
                        @Override
                        public void run() {
                            green.setEnabled(false);
                        }
                    }, 0, 1, TimeUnit.SECONDS);
                }
                else if(order.get(y) == 2){
                    final ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();
                    executorService.scheduleAtFixedRate(new Runnable() {
                        @Override
                        public void run() {
                            yellow.setEnabled(false);
                        }
                    }, 0, 1, TimeUnit.SECONDS);
                }
                else if(order.get(y) == 3) {
                    final ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();
                    executorService.scheduleAtFixedRate(new Runnable() {
                        @Override
                        public void run() {
                            red.setEnabled(false);
                        }
                    }, 0, 1, TimeUnit.SECONDS);
                }
                else if(order.get(y) == 4) {
                    final ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();
                    executorService.scheduleAtFixedRate(new Runnable() {
                        @Override
                        public void run() {
                            blue.setEnabled(false);
                        }
                    }, 0, 1, TimeUnit.SECONDS);
                }
                y += 1;
                green.setEnabled(true);
                blue.setEnabled(true);
                red.setEnabled(true);
                yellow.setEnabled(true);
            }

            ArrayList<Integer> guess = new ArrayList<>();

            y = 0;
            while (y != n + 1){
                configureBlueButton();
                configureGreenButton();
                configureRedButton();
                configureYellowButton();
                guess.add(g);
                if (!guess.get(y).equals(order.get(y))){
                    correct = false;
                    break;
                }
                y += 1;
            }

            if (!correct){
                score.setText("You Lose");
                break;
            }
            else{
                n = n + 1;
                score.setText(n);
            }
        }
    }


    public void configureGreenButton(){
        green.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                g = 1;
            }
        });
    }

    public void configureYellowButton(){
        yellow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                g = 2;
            }
        });
    }

    public void configureRedButton(){
        red.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                g = 3;
            }
        });
    }

    public void configureBlueButton(){
        blue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                g = 4;
            }
        });
    }
}